var indexSectionsWithContent =
{
  0: "acdefghiklmorstuvwxy~",
  1: "mrst",
  2: "cgmorstu",
  3: "acdeghilmorstvwxy~",
  4: "cgrs",
  5: "cs",
  6: "adrst",
  7: "aclstvxy",
  8: "mrst",
  9: "ht",
  10: "acfgkorsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "Összes",
  1: "Osztályok",
  2: "Fájl",
  3: "Függvények",
  4: "Változók",
  5: "Enumerációk",
  6: "Enumeráció-értékek",
  7: "Tulajdonságok",
  8: "Makródefiníciók",
  9: "Csoport",
  10: "Oldal"
};

