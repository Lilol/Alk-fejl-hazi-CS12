var searchData=
[
  ['tárolók_20a_20követlen_20megjelenítéshez',['Tárolók a követlen megjelenítéshez',['../group__tarolok.html',1,'']]]
];
