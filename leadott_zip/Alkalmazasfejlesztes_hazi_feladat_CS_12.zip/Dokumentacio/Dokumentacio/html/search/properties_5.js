var searchData=
[
  ['vx',['vx',['../classRobotState.html#a332589805cceeb703e7aa1699a63ab50',1,'RobotState']]],
  ['vy',['vy',['../classRobotState.html#aff7b00716cbc9fc91d1a189758874ad9',1,'RobotState']]]
];
