var searchData=
[
  ['historychanged',['historyChanged',['../classMainWindowsEventHandling.html#a100f744879416c70f6ef324cb77267a8',1,'MainWindowsEventHandling::historyChanged()'],['../classRobotStateHistory.html#a8cbccac0f660e5d4265eb206d57eae17',1,'RobotStateHistory::historyChanged()']]],
  ['historycontextupdated',['historyContextUpdated',['../classMainWindowsEventHandling.html#a6c1a8018a7bc2e7f7714fec24e16cad5',1,'MainWindowsEventHandling']]]
];
