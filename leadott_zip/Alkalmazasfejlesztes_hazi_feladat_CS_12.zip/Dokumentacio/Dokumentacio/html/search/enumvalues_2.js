var searchData=
[
  ['reset',['Reset',['../classRobotCommand.html#adf93f40f38e0ddc73af0268b2bed43f8a526d688f37a86d3c3f27d0c5016eb71d',1,'RobotCommand::Reset()'],['../classRobotState.html#a4bdbca2e0764ec2772ebc79d13796710a526d688f37a86d3c3f27d0c5016eb71d',1,'RobotState::Reset()']]]
];
