var searchData=
[
  ['sensors',['sensors',['../classRobotState.html#a7a55546455aa6d008e6eaca243e46ca3',1,'RobotState']]],
  ['status',['status',['../classRobotState.html#adee1b223980c0ed4ec5a4d8e7fbd528f',1,'RobotState']]],
  ['statusname',['statusName',['../classRobotState.html#a104cb221a80e19594d47b5db4b2e1b2b',1,'RobotState']]]
];
