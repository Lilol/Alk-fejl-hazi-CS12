var searchData=
[
  ['accelerate_5fx',['accelerate_x',['../classRobotCommand.html#a9fb0b2bb3449d6feb7a690d4ecb19f6a',1,'RobotCommand']]],
  ['accelerate_5fy',['accelerate_y',['../classRobotCommand.html#a0775629bdb433bc9678c6535dfba783c',1,'RobotCommand']]],
  ['ax',['ax',['../classRobotState.html#ae37f91e0855411ec76ca669e62273a2e',1,'RobotState']]],
  ['ay',['ay',['../classRobotState.html#a02e16858585a69198fa4074d1e8ca7e5',1,'RobotState']]]
];
