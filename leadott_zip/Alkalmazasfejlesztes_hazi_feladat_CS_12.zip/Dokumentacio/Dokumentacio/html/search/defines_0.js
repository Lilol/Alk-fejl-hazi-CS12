var searchData=
[
  ['main_5fapplication_5fh',['MAIN_APPLICATION_H',['../MainApplication_8h.html#a8e32fd040a74310a77ff6be38630d52c',1,'MainApplication.h']]],
  ['main_5fwindows_5fevent_5fhandling_5fh',['MAIN_WINDOWS_EVENT_HANDLING_H',['../MainWindowsEventHandling_8h.html#ac45dc2b187fb1a51c265053c842c37b7',1,'MainWindowsEventHandling.h']]]
];
