var searchData=
[
  ['hivatkozások_20adatkötéshez',['Hivatkozások adatkötéshez',['../group__hivatkozas.html',1,'']]]
];
