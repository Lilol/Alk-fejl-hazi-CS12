var searchData=
[
  ['erroroccurred',['errorOccurred',['../classTcpCommunication.html#a8e94bad7d6987d256fe6d73fbe94b6f2',1,'TcpCommunication']]]
];
