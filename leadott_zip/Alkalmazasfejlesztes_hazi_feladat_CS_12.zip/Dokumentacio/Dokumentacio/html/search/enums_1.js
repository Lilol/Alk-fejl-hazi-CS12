var searchData=
[
  ['status',['Status',['../classRobotState.html#a4bdbca2e0764ec2772ebc79d13796710',1,'RobotState']]]
];
