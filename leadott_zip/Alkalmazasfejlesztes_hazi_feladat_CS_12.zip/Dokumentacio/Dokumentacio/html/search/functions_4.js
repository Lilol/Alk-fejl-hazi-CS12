var searchData=
[
  ['getreceivestream',['getReceiveStream',['../classTcpCommunication.html#a13e49efb320f18554b60b28030406e05',1,'TcpCommunication']]],
  ['getsendstream',['getSendStream',['../classTcpCommunication.html#a4895d010ced069f7b9fb8738bd77f65f',1,'TcpCommunication']]],
  ['getstatusname',['getStatusName',['../classRobotState.html#a8f388f9f5c9c709d923dbb1d2ccf00a0',1,'RobotState']]]
];
