var searchData=
[
  ['felhasználói_20felület',['Felhasználói felület',['../gui.html',1,'']]]
];
