var searchData=
[
  ['az_20alkalmazás_20verziókövetése_20gitben',['Az alkalmazás verziókövetése Gitben',['../gitleiras.html',1,'']]]
];
