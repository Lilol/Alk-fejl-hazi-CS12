var searchData=
[
  ['accelerate',['Accelerate',['../classRobotCommand.html#adf93f40f38e0ddc73af0268b2bed43f8aa552e259a7aec237bbe28b9039dc3395',1,'RobotCommand::Accelerate()'],['../classRobotState.html#a4bdbca2e0764ec2772ebc79d13796710aa552e259a7aec237bbe28b9039dc3395',1,'RobotState::Accelerate()']]]
];
