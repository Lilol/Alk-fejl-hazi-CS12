var searchData=
[
  ['kommunikáció',['Kommunikáció',['../communication.html',1,'']]]
];
