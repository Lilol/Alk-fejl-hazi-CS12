var searchData=
[
  ['git',['git',['../md_git.html',1,'']]],
  ['gui',['GUI',['../md_GUI.html',1,'']]]
];
